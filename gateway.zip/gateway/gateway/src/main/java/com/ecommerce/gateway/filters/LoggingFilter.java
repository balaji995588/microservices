package com.ecommerce.gateway.filters;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.core.io.buffer.DataBufferUtils;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpRequestDecorator;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.stream.Collectors;

@Component
public class LoggingFilter implements GlobalFilter {

	private static final Logger logger = LoggerFactory.getLogger(LoggingFilter.class);

	@Override
	public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {

		ServerHttpRequest request = exchange.getRequest();

		logBasicRequestInfo(request);
		logHeaders(request);
		logQueryParams(request);
		logClientIp(request);
//		logRequestBody(exchange);

//		return logRequestBody.then(chain.filter(exchange));
		return chain.filter(exchange);
		
//        return DataBufferUtils.join(request.getBody())
//            .flatMap(dataBuffer -> {
//                byte[] bytes = new byte[dataBuffer.readableByteCount()];
//                dataBuffer.read(bytes);
//                DataBufferUtils.release(dataBuffer);  // Release original
//                String body = new String(bytes, StandardCharsets.UTF_8);
//                logger.info("Request Body: {}", body);
//
//                // Cache for reuse: retain creates shareable buffer, slice copies readable portion
//                 DataBufferUtils.retain(dataBuffer);  // Note: adjust if release above; use before read if needed
//                Flux<DataBuffer> cachedBody = Flux.just(dataBuffer.split(0));
//
//                ServerHttpRequest mutatedRequest = new ServerHttpRequestDecorator(request) {
//                    @Override
//                    public Flux<DataBuffer> getBody() {
//                        return cachedBody;
//                    }
//                };
//
//                return chain.filter(exchange.mutate().request(mutatedRequest).build());
//            });
	}

	// 🔹 Basic Info
	private void logBasicRequestInfo(ServerHttpRequest request) {
		logger.info("Request URI: {}", request.getURI());
		logger.info("HTTP Method: {}", request.getMethod());
	}

	// 🔹 Headers
	private void logHeaders(ServerHttpRequest request) {
		request.getHeaders().forEach((key, value) -> logger.info("Header '{}': {}", key, value));
	}

	// 🔹 Query Params
	private void logQueryParams(ServerHttpRequest request) {
		request.getQueryParams().forEach((key, value) -> logger.info("Query Param '{}': {}", key, value));
	}

	// 🔹 Client IP
	private void logClientIp(ServerHttpRequest request) {
		InetSocketAddress remoteAddress = request.getRemoteAddress();

		if (remoteAddress != null) {
			logger.info("Client IP: {}", remoteAddress.getAddress().getHostAddress());
		} else {
			logger.info("Client IP: Unknown");
		}
	}

	// 🔹 Request Body (IMPORTANT: Reactive handling)
	private Mono<Void> logRequestBody(ServerWebExchange exchange) {
		return exchange.getRequest().getBody().collectList().flatMap(dataBuffers -> {
			String body = dataBuffers.stream().map(this::dataBufferToString).collect(Collectors.joining());

			logger.info("Request Body: {}", body);
			return Mono.empty();
		});
	}

	private String dataBufferToString(DataBuffer buffer) {
		byte[] bytes = new byte[buffer.readableByteCount()];
		buffer.read(bytes);
		return new String(bytes, StandardCharsets.UTF_8);
	}
}
